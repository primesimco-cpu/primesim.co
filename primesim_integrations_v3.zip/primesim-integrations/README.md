# PrimeSIM Mobile — Integration Layer
## app.primesimobile.com

---

## Dosya Yapısı

```
primesim-integrations/
├── esim-access/
│   ├── esimaccess.service.js   ← eSIM Access API (primary provider)
│   ├── telnyx.service.js        ← Telnyx API (secondary provider)
│   └── esim-router.js           ← Intelligent routing + failover
├── stripe/
│   └── stripe.service.js        ← Stripe payments + webhooks
├── auth/
│   └── auth.service.js          ← Google OAuth + Apple Sign In
├── api-routes/
│   ├── handlers.js              ← Express/Fastify handlers
│   └── nextjs-routes.js         ← Next.js App Router
├── tests/
│   └── run-tests.js             ← Integration test suite
└── package.json
```

---

## Kurulum (5 adım)

### 1. Bağımlılıkları yükle
```bash
npm install
```

### 2. .env dosyasını doldur
```bash
cp ../.env.example .env
# Her satırdaki "BURAYA_EKLE" değerini gerçek key ile değiştir
```

### 3. API Key'leri al

**eSIM Access** (15 dakika):
1. https://esimaccess.com → Sign Up
2. Dashboard → API → Get API Key (sandbox instant)
3. .env → `ESIMACCESS_API_KEY=ea_sandbox_xxx`

**Stripe** (10 dakika):
1. https://stripe.com → Register
2. Dashboard → Developers → API Keys
3. .env → `STRIPE_SECRET_KEY=sk_test_xxx`
4. .env → `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_xxx`
5. Webhook: Dashboard → Developers → Webhooks → Add Endpoint
   - URL: `https://api.primesimobile.com/webhooks/stripe`
   - Events: `payment_intent.succeeded`, `payment_intent.payment_failed`, `charge.refunded`
6. .env → `STRIPE_WEBHOOK_SECRET=whsec_xxx`

**Google OAuth** (10 dakika):
1. https://console.cloud.google.com → New Project → "PrimeSIM Mobile"
2. APIs & Services → Credentials → Create OAuth Client ID
3. Application type: Web application
4. Authorized redirect URIs: `https://app.primesimobile.com/api/auth/callback/google`
5. .env → `GOOGLE_CLIENT_ID=xxx.apps.googleusercontent.com`
6. .env → `GOOGLE_CLIENT_SECRET=GOCSPX-xxx`

**Apple Sign In** (30 dakika — Apple review gerektirir):
1. developer.apple.com → Certificates → Identifiers → App IDs
2. Enable "Sign In with Apple"
3. Keys → Create Key → Sign In with Apple → Download .p8
4. .env → `APPLE_ID=com.primesimobile.app`
5. .env → `APPLE_TEAM_ID=YOUR_TEAM_ID`
6. .env → `APPLE_KEY_ID=YOUR_KEY_ID`
7. .env → `APPLE_PRIVATE_KEY=$(cat AuthKey_xxx.p8)`

### 4. Testleri çalıştır
```bash
# Tüm testler (API key yoksa ilgili testler skip edilir)
npm test

# Çıktı:
# ✅ PASS  Health check
# ✅ PASS  List packages (global)
# ✅ PASS  Create order (sandbox)
# ✅ PASS  Stripe Payment Intent ($12)
# ✅ PASS  Coupon PRIME20
# ✅ PASS  E2E flow: intent → provision
```

### 5. Next.js'e entegre et
```
Kopyala:
api-routes/handlers.js  →  src/app/api/*/route.js
stripe/stripe.service.js →  src/lib/stripe.js
esim-access/            →  src/lib/esim/
```

---

## API Endpoint'leri

| Method | Endpoint                        | Açıklama                        |
|--------|---------------------------------|---------------------------------|
| GET    | /api/plans?country=JP           | Ülke planlarını listele          |
| POST   | /api/orders                     | Sipariş oluştur + Payment Intent|
| POST   | /api/coupons/validate           | Kupon kodu doğrula               |
| GET    | /api/esims/:iccid/usage         | eSIM veri kullanımı              |
| POST   | /api/orders/:id/refund          | İade işlemi                     |
| POST   | /api/webhooks/stripe            | Stripe webhook (raw body)       |
| POST   | /api/webhooks/esimaccess        | eSIM Access webhook             |
| GET    | /api/health                     | Provider sağlık durumu           |

---

## Ödeme Akışı

```
Kullanıcı "Satın Al" tıklar
        ↓
POST /api/orders
→ Stripe PaymentIntent oluşturulur
→ clientSecret frontend'e döner
        ↓
Stripe.js confirmPayment(clientSecret)
→ Kullanıcı kart bilgisi girer
→ Stripe 3D Secure çalıştırır
        ↓
Stripe → POST /api/webhooks/stripe
→ payment_intent.succeeded eventi
→ eSIM Router → eSIM Access API
→ ICCID + LPA kodu alınır
→ E-posta + push notification gönderilir
        ↓
Kullanıcı eSIM'i kurar
```

---

## Provider Failover

```
Sipariş gelir
      ↓
eSIM Router
  → eSIM Access (Priority 1, healthy?) ──→ ICCID döner ✓
  → Telnyx (Priority 2, failover)       ──→ ICCID döner ✓ (Access fail ise)
  → Her 5 dakikada health check
  → 3 ardışık hata → provider unhealthy
  → Tüm provider'lar fail → hata fırlat
```

---

## Test Senaryoları

```bash
# Sandbox kart numaraları (Stripe test modu):
4242 4242 4242 4242  →  Başarılı ödeme
4000 0000 0000 0002  →  Kart reddedildi
4000 0025 0000 3155  →  3D Secure gerekli
4000 0000 0000 9995  →  İnsufficient funds

# Test kupon kodları:
PRIME20    → %20 indirim
SUMMER30   → %30 indirim
BUSINESS25 → %25 indirim
FLASH40    → %40 indirim
```
